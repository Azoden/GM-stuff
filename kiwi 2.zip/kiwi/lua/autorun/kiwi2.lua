player_manager.AddValidModel( "Kiwi2", "models/TSBB/Animals/Kiwi2.mdl")
list.Set( "PlayerOptionsModel", "Kiwi2", "models/TSBB/Animals/Kiwi2.mdl")
